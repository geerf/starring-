set(CMAKE_HOST_SYSTEM "HarmonyOS-HongMeng Kernel 1.13.0")
set(CMAKE_HOST_SYSTEM_NAME "HarmonyOS")
set(CMAKE_HOST_SYSTEM_VERSION "HongMeng Kernel 1.13.0")
set(CMAKE_HOST_SYSTEM_PROCESSOR "unknown")

include("/data/service/hnp/hmos-clt.org/hmos-clt_1.0.0/sdk/default/hms/native/build/cmake/hmos.toolchain.bisheng.cmake")

set(CMAKE_SYSTEM "OHOS-1")
set(CMAKE_SYSTEM_NAME "OHOS")
set(CMAKE_SYSTEM_VERSION "1")
set(CMAKE_SYSTEM_PROCESSOR "aarch64")

set(CMAKE_CROSSCOMPILING "TRUE")

set(CMAKE_SYSTEM_LOADED 1)
