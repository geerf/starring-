#ifndef STAR_RING_RENDERER_H
#define STAR_RING_RENDERER_H

#include <cstdint>
#include <atomic>
#include <condition_variable>
#include <mutex>
#include <random>
#include <thread>
#include <EGL/egl.h>
#include <GLES3/gl3.h>

// 星环 GPU 渲染器：XComponent(SURFACE) + EGL/GLES3 点精灵粒子系统。
// 3200 环粒子 + 160 尘埃全部由顶点着色器解析计算（自转/抖动/闪烁/呼吸/入场
// /深度增亮/喷射均为时间 t 的初等函数），CPU 每帧仅更新少量 uniform。
// 渲染线程 vsync 自驱 + 60fps 节流 sleep，主线程零参与。

class StarRingRenderer {
public:
    static StarRingRenderer& instance();

    // XComponent surface 生命周期（native 回调线程调用）
    void onSurfaceCreated(void* nativeWindow);
    // OnSurfaceCreated 时主动查询到尺寸的入口（防御 OnSurfaceChanged 不触发）
    void onSurfaceCreatedWithSize(void* nativeWindow, int32_t wPx, int32_t hPx);
    void onSurfaceChanged(int32_t wPx, int32_t hPx);
    void onSurfaceDestroyed();

    // ArkTS 调用（NAPI）
    void pause();
    void resume();
    void setDensity(float vpToPx);
    // 应用内嵌模式：cxRatio/cyRatio=环心在 surface 内的宽高比例；
    // baseWidthVp>0 时以该宽度为环基准宽（wd_）并跳过 vignette（方盒四角会露边），
    // baseWidthVp=0 恢复独立全屏模式（CENTER_X/Y_RATIO + 自动 wd_ + vignette）
    void setCenter(float cxRatio, float cyRatio, float baseWidthVp);

private:
    StarRingRenderer();
    ~StarRingRenderer();
    StarRingRenderer(const StarRingRenderer&) = delete;
    StarRingRenderer& operator=(const StarRingRenderer&) = delete;

    void startThread();
    void renderLoop();
    bool initGL();
    void destroyGL();
    void buildParticles();
    void spawnEjects(double t);
    bool particleBusy(int32_t idx) const;
    float rand01();
    int pickIndex(const float* weights, int n, float r);
    float smoothstep(float k) const;
    float radialBright(float rho) const;
    const float* zoneWeightsOf(float rho) const;
    void hexToRgb(float* out, uint32_t hex) const;

    // ---- 配置（与 ArkTS StarRingEngine 保持一致的观感参数）----
    static constexpr int32_t RING_COUNT = 3840;  // 密度 +20%（原 3200，与原版 Canvas 一致）
    static constexpr int32_t DUST_COUNT = 192;
    static constexpr int32_t MAX_EJECT_SLOTS = 32;
    static constexpr int32_t COLOR_COUNT = 7;
    static constexpr int32_t TIER_COUNT = 6;
    static constexpr float CENTER_X_RATIO = 0.52f;
    static constexpr float CENTER_Y_RATIO = 0.44f;
    static constexpr float HOLE_RATIO = 0.17f;
    static constexpr float PEAK_RATIO = 0.33f;
    static constexpr float RHO_MIN = 0.20f;
    static constexpr float RHO_MAX = 0.47f;
    static constexpr float TILT_DEG = 6.0f;
    static constexpr float SQUASH_Y = 0.96f;
    static constexpr float ROTATION_PERIOD_S = 20.0f;
    static constexpr float DIFF_MAX = 2.2f;
    static constexpr float JITTER_AMP_PX = 5.0f;
    static constexpr float BREATH_AMP = 0.02f;
    static constexpr float BREATH_PERIOD_S = 5.0f;
    static constexpr float ENTRANCE_DUR_S = 0.6f;
    static constexpr float BURST_MIN_PX = 10.0f;   // 入场迸发起点：距环心最小距离（px@1080），小值=从中心亮点迸开
    static constexpr float BURST_MAX_PX = 30.0f;
    static constexpr float EJECT_INTERVAL_S = 2.5f;
    static constexpr int32_t EJECT_COUNT_MIN = 3;
    static constexpr int32_t EJECT_COUNT_MAX = 8;
    static constexpr float EJECT_DIST_PX = 110.0f;
    static constexpr float EJECT_DUR_MIN_S = 0.8f;
    static constexpr float EJECT_DUR_MAX_S = 1.5f;
    static constexpr float REFILL_FADE_S = 0.35f;
    static constexpr float TWINKLE_AMP = 0.28f;
    static constexpr float ACCENT_FRAC = 0.015f;
    static constexpr float VIGNETTE_STRENGTH = 0.55f;
    static constexpr float BG_R = 5.0f / 255.0f;
    static constexpr float BG_G = 5.0f / 255.0f;
    static constexpr float BG_B = 7.0f / 255.0f;

    // 六档精灵 profile：coreStop / midStop / glow
    static constexpr float SPRITE_STOPS[TIER_COUNT][3] = {
        {0.20f, 0.42f, 3.4f},
        {0.20f, 0.42f, 3.2f},
        {0.22f, 0.44f, 3.0f},
        {0.18f, 0.40f, 2.8f},
        {0.15f, 0.38f, 2.6f},
        {0.10f, 0.34f, 2.4f},
    };
    static constexpr float SPRITE_CORE_PX[TIER_COUNT] = {3.0f, 4.5f, 6.0f, 8.0f, 11.0f, 16.0f};
    static constexpr float SPRITE_WEIGHT[TIER_COUNT] = {0.30f, 0.28f, 0.22f, 0.10f, 0.05f, 0.05f};
    // 7 色板：0-3 主变体，4-6 彩色微粒（蓝/青/黄绿）
    static constexpr uint32_t COLOR_HEX[COLOR_COUNT][4] = {
        {0xFFFFFF, 0xEDEDF4, 0xC4C4E2, 0x9C9CC8},
        {0xFFFFFF, 0xE6E6F0, 0xB4B4DC, 0x8C8CC0},
        {0xFFFFFF, 0xE0E0EE, 0xA4A4D6, 0x7C7CB4},
        {0xEDEDF4, 0xD6D6E8, 0x9494CC, 0x6C6CA8},
        {0x9D9DFF, 0x4D4DFF, 0x4D4DFF, 0x4D4DFF},
        {0xABEEEE, 0x66E0E0, 0x66E0E0, 0x66E0E0},
        {0xEAF2A8, 0xD9E860, 0xD9E860, 0xD9E860},
    };
    static constexpr float ZONE_W_INNER[4] = {0.45f, 0.35f, 0.15f, 0.05f};
    static constexpr float ZONE_W_MID[4] = {0.30f, 0.40f, 0.22f, 0.08f};
    static constexpr float ZONE_W_OUTER[4] = {0.15f, 0.35f, 0.32f, 0.18f};
    static constexpr float ZONE_W_FAR[4] = {0.05f, 0.20f, 0.40f, 0.35f};
    static constexpr float ACCENT_W[3] = {0.60f, 0.27f, 0.13f};

    // ---- 运行时状态 ----
    std::thread thread_;
    std::atomic<bool> threadRunning_{false};
    std::atomic<bool> paused_{false};
    std::atomic<bool> surfaceValid_{false};
    std::atomic<bool> glReady_{false};
    std::mutex mtx_;                 // 保护 slots_/喷射调度参数
    std::condition_variable pauseCv_;

    void* nativeWindow_ = nullptr;   // OHNativeWindow*（系统持有，不负责释放）
    EGLDisplay display_ = EGL_NO_DISPLAY;
    EGLContext context_ = EGL_NO_CONTEXT;
    EGLSurface surface_ = EGL_NO_SURFACE;

    std::atomic<int32_t> surfW_{0};  // 物理像素
    std::atomic<int32_t> surfH_{0};
    std::atomic<float> density_{1.0f}; // vp→px
    // 应用内嵌模式参数（ArkTS 线程 setCenter 写入，渲染线程每帧读取）
    std::atomic<float> cxRatio_{CENTER_X_RATIO};
    std::atomic<float> cyRatio_{CENTER_Y_RATIO};
    std::atomic<float> baseWVp_{0.0f};

    // GL 资源（渲染线程独占）
    GLuint ringProgram_ = 0;
    GLuint dustProgram_ = 0;
    GLuint vigProgram_ = 0;
    GLuint ringVao_ = 0;
    GLuint ringVbo_ = 0;
    GLuint dustVao_ = 0;
    GLuint dustVbo_ = 0;
    GLuint quadVao_ = 0;
    GLuint quadVbo_ = 0;
    GLint ringUniforms_[10] = {0};
    GLint dustUniforms_[6] = {0};
    GLint vigUniforms_[2] = {0};
    float ptMax_ = 256.0f;

    // 派生几何（vp 基准，渲染线程内计算）
    float wVp_ = 0.0f;
    float hVp_ = 0.0f;
    float scale1080_ = 0.0f;
    float wd_ = 0.0f;
    float cxVp_ = 0.0f;
    float cyVp_ = 0.0f;
    float jitAmpVp_ = 0.0f;
    float cT_ = 1.0f;
    float sT_ = 0.0f;
    float sq_ = 1.0f;
    float depthNorm_ = 1.0f;
    float breathPhase_ = 0.0f;

    // 喷射槽（渲染线程独占）
    struct EjectSlot {
        int32_t idx;
        float t0;
        float dur;
        float dist;
        float dirX;
        float dirY;
    };
    EjectSlot slots_[MAX_EJECT_SLOTS] = {};
    float ejectUploadA_[MAX_EJECT_SLOTS][4] = {};
    float ejectUploadB_[MAX_EJECT_SLOTS][4] = {};
    double nextEjectAt_ = 0.0;
    // 粒子轨道备份（theta0, omega, rho, h）：喷射方向计算用
    float orbitBackup_[RING_COUNT * 4] = {};

    // 粒子几何常量（buildParticles 计算）
    float ringR_ = 0.0f;
    float tubeR_ = 0.0f;
    float baseOmega_ = 0.0f;

    std::mt19937 rng_{12345};
    bool firstFrameLogged_ = false; // 首帧一次性诊断日志（渲染线程独占）
};

#endif
