// StarringFX: XComponent(SURFACE) 生命周期桥接 + 星环渲染器 NAPI 接口
#include <hilog/log.h>
#include <ace/xcomponent/native_interface_xcomponent.h>
#include <napi/native_api.h>
#include "star_ring_renderer.h"

#undef LOG_DOMAIN
#undef LOG_TAG
#define LOG_DOMAIN 0x0501
#define LOG_TAG "StarringFX"

// ===== 星环 GPU 渲染：XComponent(SURFACE) 生命周期桥接 =====
// XComponent({libraryname: 'starringfx'}) 加载 so 时，Init/onLoad 收到含
// OH_NATIVE_XCOMPONENT_OBJ 属性的 exports；双路径注册（幂等）。
static void OnSrSurfaceCreated(OH_NativeXComponent* component, void* window)
{
    // 主动查询尺寸：部分场景 OnSurfaceChanged 不触发/被错过，
    // 创建时刻就带上尺寸可避免渲染线程因 surfW/H=0 空转黑屏
    uint64_t w = 0;
    uint64_t h = 0;
    if (OH_NativeXComponent_GetXComponentSize(component, window, &w, &h) ==
            OH_NATIVEXCOMPONENT_RESULT_SUCCESS && w > 0 && h < 0xFFFFFFFFull) {
        StarRingRenderer::instance().onSurfaceCreatedWithSize(window, (int32_t)w, (int32_t)h);
    } else {
        OH_LOG_WARN(LOG_APP, "StarringFX OnSurfaceCreated size query fail");
        StarRingRenderer::instance().onSurfaceCreated(window);
    }
}

static void OnSrSurfaceChanged(OH_NativeXComponent* component, void* window)
{
    uint64_t w = 0;
    uint64_t h = 0;
    if (OH_NativeXComponent_GetXComponentSize(component, window, &w, &h) ==
        OH_NATIVEXCOMPONENT_RESULT_SUCCESS) {
        StarRingRenderer::instance().onSurfaceChanged((int32_t)w, (int32_t)h);
    }
}

static void OnSrSurfaceDestroyed(OH_NativeXComponent* component, void* window)
{
    (void)component;
    (void)window;
    StarRingRenderer::instance().onSurfaceDestroyed();
}

static bool RegisterStarRingXComp(napi_env env, napi_value carrier)
{
    if (env == nullptr || carrier == nullptr) {
        return false;
    }
    napi_value exportInstance = nullptr;
    if (napi_get_named_property(env, carrier, OH_NATIVE_XCOMPONENT_OBJ, &exportInstance) != napi_ok ||
        exportInstance == nullptr) {
        return false;
    }
    napi_valuetype vt = napi_undefined;
    napi_typeof(env, exportInstance, &vt);
    if (vt != napi_object) {
        return false;
    }
    OH_NativeXComponent* nativeXComponent = nullptr;
    if (napi_unwrap(env, exportInstance, reinterpret_cast<void**>(&nativeXComponent)) != napi_ok ||
        nativeXComponent == nullptr) {
        return false;
    }
    // 零初始化回调结构：未设置的回调（触摸/悬停/按键等）不会被触发
    static OH_NativeXComponent_Callback cb = {};
    cb.OnSurfaceCreated = OnSrSurfaceCreated;
    cb.OnSurfaceChanged = OnSrSurfaceChanged;
    cb.OnSurfaceDestroyed = OnSrSurfaceDestroyed;
    cb.DispatchTouchEvent = nullptr;
    if (OH_NativeXComponent_RegisterCallback(nativeXComponent, &cb) != OH_NATIVEXCOMPONENT_RESULT_SUCCESS) {
        OH_LOG_ERROR(LOG_APP, "StarringFX OH_NativeXComponent_RegisterCallback fail");
        return false;
    }
    OH_LOG_WARN(LOG_APP, "StarringFX xcomponent callbacks registered");
    return true;
}

// XComponent onLoad(ctx) 传入的 exports 注册 surface 回调（主注册路径）
static napi_value RegisterStarRingContext(napi_env env, napi_callback_info info)
{
    size_t argc = 1;
    napi_value args[1] = {nullptr};
    napi_get_cb_info(env, info, &argc, args, nullptr, nullptr);
    bool ok = false;
    if (argc >= 1) {
        ok = RegisterStarRingXComp(env, args[0]);
    }
    napi_value ret;
    napi_get_boolean(env, ok, &ret);
    return ret;
}

static napi_value SetStarRingDensity(napi_env env, napi_callback_info info)
{
    size_t argc = 1;
    napi_value args[1] = {nullptr};
    napi_get_cb_info(env, info, &argc, args, nullptr, nullptr);
    double d = 0.0;
    if (argc >= 1 && napi_get_value_double(env, args[0], &d) == napi_ok) {
        StarRingRenderer::instance().setDensity((float)d);
    }
    napi_value ret;
    napi_get_undefined(env, &ret);
    return ret;
}

// 应用内嵌模式：环心比例 + 环基准宽（vp）；baseWidthVp=0 恢复独立全屏模式
static napi_value SetStarRingCenter(napi_env env, napi_callback_info info)
{
    size_t argc = 3;
    napi_value args[3] = {nullptr, nullptr, nullptr};
    napi_get_cb_info(env, info, &argc, args, nullptr, nullptr);
    double cx = 0.0;
    double cy = 0.0;
    double baseW = 0.0;
    if (argc >= 1) {
        napi_get_value_double(env, args[0], &cx);
    }
    if (argc >= 2) {
        napi_get_value_double(env, args[1], &cy);
    }
    if (argc >= 3) {
        napi_get_value_double(env, args[2], &baseW);
    }
    StarRingRenderer::instance().setCenter((float)cx, (float)cy, (float)baseW);
    napi_value ret;
    napi_get_undefined(env, &ret);
    return ret;
}

// 窗口拉伸：PC 端 XComponent OnSurfaceChanged 不回调，surface 视口由 ArkTS 主动推送（px）
static napi_value NotifyStarRingSurfaceSize(napi_env env, napi_callback_info info)
{
    size_t argc = 2;
    napi_value args[2] = {nullptr, nullptr};
    napi_get_cb_info(env, info, &argc, args, nullptr, nullptr);
    double wPx = 0.0;
    double hPx = 0.0;
    if (argc >= 1) {
        napi_get_value_double(env, args[0], &wPx);
    }
    if (argc >= 2) {
        napi_get_value_double(env, args[1], &hPx);
    }
    StarRingRenderer::instance().onSurfaceChanged((int32_t)wPx, (int32_t)hPx);
    napi_value ret;
    napi_get_undefined(env, &ret);
    return ret;
}

static napi_value StarRingPause(napi_env env, napi_callback_info info)
{
    (void)env;
    (void)info;
    StarRingRenderer::instance().pause();
    napi_value ret;
    napi_get_undefined(env, &ret);
    return ret;
}

static napi_value StarRingResume(napi_env env, napi_callback_info info)
{
    (void)env;
    (void)info;
    StarRingRenderer::instance().resume();
    napi_value ret;
    napi_get_undefined(env, &ret);
    return ret;
}

EXTERN_C_START
static napi_value Init(napi_env env, napi_value exports) {
    RegisterStarRingXComp(env, exports);
    napi_property_descriptor desc[] = {
        {"registerStarRingContext", nullptr, RegisterStarRingContext, nullptr, nullptr, nullptr, napi_default, nullptr},
        {"setStarRingDensity", nullptr, SetStarRingDensity, nullptr, nullptr, nullptr, napi_default, nullptr},
        {"setStarRingCenter", nullptr, SetStarRingCenter, nullptr, nullptr, nullptr, napi_default, nullptr},
        {"notifyStarRingSurfaceSize", nullptr, NotifyStarRingSurfaceSize, nullptr, nullptr, nullptr, napi_default, nullptr},
        {"starRingPause", nullptr, StarRingPause, nullptr, nullptr, nullptr, napi_default, nullptr},
        {"starRingResume", nullptr, StarRingResume, nullptr, nullptr, nullptr, napi_default, nullptr},
    };
    napi_define_properties(env, exports, sizeof(desc) / sizeof(desc[0]), desc);
    return exports;
}
EXTERN_C_END

static napi_module demoModule = {
    .nm_version = 1,
    .nm_flags = 0,
    .nm_filename = nullptr,
    .nm_register_func = Init,
    .nm_modname = "starringfx",
    .nm_priv = ((void *)0),
    .reserved = {0},
};

extern "C" __attribute__((constructor)) void RegisterModule(void) { napi_module_register(&demoModule); }
