cmake_minimum_required(VERSION 3.4.1)
project(StarringFX)

set(CMAKE_CXX_STANDARD 17)

add_library(starringfx SHARED
    napi_init.cpp
    star_ring_renderer.cpp
)

target_include_directories(starringfx PRIVATE
    ${CMAKE_CURRENT_SOURCE_DIR}
)

target_link_libraries(starringfx PUBLIC
    libace_napi.z.so
    libace_ndk.z.so
    libhilog_ndk.z.so
    libEGL.so
    libGLESv3.so
)
