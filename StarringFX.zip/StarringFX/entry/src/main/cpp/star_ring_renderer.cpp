#include "star_ring_renderer.h"

#include <chrono>
#include <cmath>
#include <hilog/log.h>
#include <vector>

#undef LOG_DOMAIN
#undef LOG_TAG
#define LOG_DOMAIN 0x0501
#define LOG_TAG "StarRingGL"

namespace {
constexpr float TWO_PI = 6.28318530717958647692f;
constexpr double FRAME_INTERVAL_MS = 16.6667; // 60fps 节流

// ===== 环粒子顶点着色器：全部运动解析化，GPU 逐帧计算 =====
const char* RING_VS = "#version 300 es\n"
"precision highp float;\n"
"layout(location=0) in vec4 aOrbit;\n"   // theta0, omega, rho, h
"layout(location=1) in vec4 aLook;\n"    // baseA, sizeCorePx, tier, colorIdx
"layout(location=2) in vec4 aJit;\n"     // jF1, jF2, jP1, jP2
"layout(location=3) in vec4 aTw;\n"      // twF, twP, burstD, seed
"uniform vec4 uP0;\n"                    // t, pe, gs, gAlpha
"uniform vec4 uP1;\n"                    // wVp, hVp, density, scale1080
"uniform vec4 uP2;\n"                    // Wd, cx, cy, jitAmp
"uniform vec4 uP3;\n"                    // cT, sT, sq, depthNorm
"uniform vec4 uP4;\n"                    // refillFade, ptMax, twinkleAmp, ejectOn
"uniform vec4 uEjectA[32];\n"            // idx, t0, dur, dist
"uniform vec4 uEjectB[32];\n"            // dirX, dirY, 0, 0
"uniform vec3 uSprite[6];\n"             // coreStop, midStop, glow
"uniform vec3 uColCore[7];\n"
"uniform vec3 uColInner[7];\n"
"uniform vec3 uColMid[7];\n"
"uniform vec3 uColEdge[7];\n"
"out float vAlpha;\n"
"out vec2 vStops;\n"
"out vec3 vCA;\n"
"out vec3 vCB;\n"
"out vec3 vCC;\n"
"out vec3 vCD;\n"
"void main() {\n"
"    float t = uP0.x;\n"
"    int self = gl_VertexID;\n"
"    float aMul = 1.0;\n"
"    vec2 eo = vec2(0.0);\n"
"    if (uP4.w > 0.5) {\n"
"        for (int s = 0; s < 32; s++) {\n"
"            if (int(uEjectA[s].x) == self) {\n"
"                float et = t - uEjectA[s].y;\n"
"                if (et >= 0.0) {\n"
"                    float dur = uEjectA[s].z;\n"
"                    if (et < dur) {\n"
"                        float k = et / dur;\n"
"                        float dd = uEjectA[s].w * (1.0 - (1.0 - k) * (1.0 - k));\n"
"                        eo = uEjectB[s].xy * dd;\n"
"                        aMul = 1.0 - k;\n"
"                    } else {\n"
"                        float rf = (et - dur) / uP4.x;\n"
"                        aMul = rf >= 1.0 ? 1.0 : rf;\n"
"                    }\n"
"                }\n"
"                break;\n"
"            }\n"
"        }\n"
"    }\n"
"    float th = aOrbit.x + aOrbit.y * t;\n"
"    float cs = cos(th);\n"
"    float sn = sin(th);\n"
"    float rx = aOrbit.z * uP2.x;\n"
"    float hv = aOrbit.w * uP2.x;\n"
"    float bD = aTw.z * uP1.w;\n"
"    rx = bD + (rx - bD) * uP0.y;\n"
"    hv *= uP0.y;\n"
"    float jx = uP2.w * (sin(t * aJit.x + aJit.z) + 0.45 * sin(t * aJit.y + aJit.w)) * 0.69;\n"
"    float jy = uP2.w * (sin(t * aJit.x + aJit.z + 2.1) + 0.45 * sin(t * aJit.y + aJit.w + 4.4)) * 0.69;\n"
"    float dn = (hv * uP3.x - rx * sn * uP3.y) / uP3.w;\n"
"    float a = aLook.x * (1.0 - uP4.z * (0.5 - 0.5 * sin(t * aTw.x + aTw.y)))\n"
"            * (1.0 + 0.4 * dn) * uP0.w * aMul;\n"
"    a = clamp(a, 0.0, 1.0);\n"
"    float sx = uP2.y + rx * cs * uP0.z + jx + eo.x;\n"
"    float sy = uP2.z + (rx * sn * uP3.x + hv * uP3.y) * uP3.z * uP0.z + jy + eo.y;\n"
"    vec2 px = vec2(sx, sy) * uP1.z;\n"
"    float halfW = uP1.x * uP1.z * 0.5;\n"
"    float halfH = uP1.y * uP1.z * 0.5;\n"
"    gl_Position = vec4(px.x / halfW - 1.0, 1.0 - px.y / halfH, 0.0, 1.0);\n"
"    int tier = int(aLook.z);\n"
"    int ci = int(aLook.w);\n"
"    float dW = aLook.y * uSprite[tier].z * uP1.w;\n"
"    float sz = dW * (1.0 + 0.25 * dn);\n"
"    gl_PointSize = min(sz * uP1.z, uP4.y);\n"
"    vAlpha = a;\n"
"    vStops = uSprite[tier].xy;\n"
"    vCA = uColCore[ci];\n"
"    vCB = uColInner[ci];\n"
"    vCC = uColMid[ci];\n"
"    vCD = uColEdge[ci];\n"
"}\n";

// ===== 点精灵片元（环粒子/尘埃共用）：gl_PointCoord 径向四段渐变，加性混合 =====
const char* POINT_FS = "#version 300 es\n"
"precision mediump float;\n"
"in float vAlpha;\n"
"in vec2 vStops;\n"
"in vec3 vCA;\n"
"in vec3 vCB;\n"
"in vec3 vCC;\n"
"in vec3 vCD;\n"
"out vec4 fragColor;\n"
"void main() {\n"
"    vec2 pc = gl_PointCoord * 2.0 - 1.0;\n"
"    float d = length(pc);\n"
"    if (d >= 1.0) { discard; }\n"
"    float c0 = vStops.x;\n"
"    float m0 = vStops.y;\n"
"    vec3 col;\n"
"    float a;\n"
"    if (d <= c0) {\n"
"        col = mix(vCA, vCB, d / max(c0, 1e-4));\n"
"        a = 1.0;\n"
"    } else if (d <= m0) {\n"
"        float k = (d - c0) / max(m0 - c0, 1e-4);\n"
"        col = mix(vCB, vCC, k);\n"
"        a = mix(1.0, 0.38, k);\n"
"    } else {\n"
"        float k = (d - m0) / max(1.0 - m0, 1e-4);\n"
"        col = mix(vCC, vCD, k);\n"
"        a = 0.38 * (1.0 - k);\n"
"    }\n"
"    float total = a * vAlpha;\n"
"    fragColor = vec4(col * total, total);\n"
"}\n";

// ===== 尘埃顶点着色器：上浮/闪烁解析化 =====
const char* DUST_VS = "#version 300 es\n"
"precision highp float;\n"
"layout(location=0) in vec4 aD0;\n"  // x0, y0, sizePx, speedPxS
"layout(location=1) in vec4 aD1;\n"  // alpha, twF, twP, seed
"uniform vec4 uP0;\n"                // t, pe, gs, gAlpha
"uniform vec4 uP1;\n"                // wVp, hVp, density, scale1080
"uniform vec4 uP4;\n"                // refillFade, ptMax, twinkleAmp, ejectOn
"uniform vec3 uColC0;\n"
"uniform vec3 uColC1;\n"
"uniform vec3 uColC2;\n"
"uniform vec3 uColC3;\n"
"out float vAlpha;\n"
"out vec2 vStops;\n"
"out vec3 vCA;\n"
"out vec3 vCB;\n"
"out vec3 vCC;\n"
"out vec3 vCD;\n"
"void main() {\n"
"    float t = uP0.x;\n"
"    float dy = fract(aD0.y - (aD0.w * uP1.w / uP1.y) * t);\n"
"    float a = aD1.x * (0.55 + 0.45 * dy) * (1.0 - 0.45 * (0.5 - 0.5 * sin(t * aD1.y + aD1.z))) * uP0.w;\n"
"    a = clamp(a, 0.0, 1.0);\n"
"    vec2 px = vec2(aD0.x * uP1.x, dy * uP1.y) * uP1.z;\n"
"    float halfW = uP1.x * uP1.z * 0.5;\n"
"    float halfH = uP1.y * uP1.z * 0.5;\n"
"    gl_Position = vec4(px.x / halfW - 1.0, 1.0 - px.y / halfH, 0.0, 1.0);\n"
"    float sz = aD0.z * 3.4 * uP1.w;\n"
"    gl_PointSize = min(sz * uP1.z, uP4.y);\n"
"    vAlpha = a;\n"
"    vStops = vec2(0.20, 0.42);\n"
"    vCA = uColC0;\n"
"    vCB = uColC1;\n"
"    vCC = uColC2;\n"
"    vCD = uColC3;\n"
"}\n";

// ===== 全屏 quad（vignette）=====
const char* QUAD_VS = "#version 300 es\n"
"precision highp float;\n"
"layout(location=0) in vec2 aPos;\n"
"out vec2 vUv;\n"
"void main() {\n"
"    vUv = aPos * 0.5 + 0.5;\n"
"    gl_Position = vec4(aPos, 0.0, 1.0);\n"
"}\n";

const char* VIG_FS = "#version 300 es\n"
"precision mediump float;\n"
"in vec2 vUv;\n"
"uniform vec2 uVig;\n"  // vignetteStrength, gAlpha
"out vec4 fragColor;\n"
"void main() {\n"
"    float halfDiag = 0.70710678;\n"
"    float r = length(vUv - 0.5);\n"
"    float k = clamp((r - 0.30 * halfDiag) / (1.02 * halfDiag - 0.30 * halfDiag), 0.0, 1.0);\n"
"    float vs = uVig.x;\n"
"    float a = k < 0.55 ? (vs * 0.22 * (k / 0.55)) : mix(vs * 0.22, vs, (k - 0.55) / 0.45);\n"
"    a *= uVig.y;\n"
"    fragColor = vec4(vec3(2.0, 2.0, 10.0) / 255.0, a);\n"
"}\n";

GLuint compileShader(GLenum type, const char* src) {
    GLuint sh = glCreateShader(type);
    glShaderSource(sh, 1, &src, nullptr);
    glCompileShader(sh);
    GLint ok = GL_FALSE;
    glGetShaderiv(sh, GL_COMPILE_STATUS, &ok);
    if (ok != GL_TRUE) {
        char log[1024] = {0};
        GLsizei len = 0;
        glGetShaderInfoLog(sh, sizeof(log) - 1, &len, log);
        OH_LOG_ERROR(LOG_APP, "StarRingGL shader compile fail: %{public}s", log);
        glDeleteShader(sh);
        return 0;
    }
    return sh;
}

GLuint linkProgram(const char* vs, const char* fs) {
    GLuint v = compileShader(GL_VERTEX_SHADER, vs);
    GLuint f = compileShader(GL_FRAGMENT_SHADER, fs);
    if (v == 0 || f == 0) {
        if (v != 0) glDeleteShader(v);
        if (f != 0) glDeleteShader(f);
        return 0;
    }
    GLuint prog = glCreateProgram();
    glAttachShader(prog, v);
    glAttachShader(prog, f);
    glLinkProgram(prog);
    glDeleteShader(v);
    glDeleteShader(f);
    GLint ok = GL_FALSE;
    glGetProgramiv(prog, GL_LINK_STATUS, &ok);
    if (ok != GL_TRUE) {
        char log[1024] = {0};
        GLsizei len = 0;
        glGetProgramInfoLog(prog, sizeof(log) - 1, &len, log);
        OH_LOG_ERROR(LOG_APP, "StarRingGL program link fail: %{public}s", log);
        glDeleteProgram(prog);
        return 0;
    }
    return prog;
}
} // namespace

StarRingRenderer& StarRingRenderer::instance() {
    static StarRingRenderer inst;
    return inst;
}

StarRingRenderer::StarRingRenderer() {
    std::random_device rd;
    rng_.seed(rd());
}

StarRingRenderer::~StarRingRenderer() {
    onSurfaceDestroyed();
}

void StarRingRenderer::onSurfaceCreated(void* nativeWindow) {
    if (nativeWindow == nullptr) {
        OH_LOG_ERROR(LOG_APP, "StarRingGL onSurfaceCreated: null window");
        return;
    }
    // 若已有线程（异常路径），先停
    if (threadRunning_.load()) {
        OH_LOG_WARN(LOG_APP, "StarRingGL surface recreate while running, restart");
        onSurfaceDestroyed();
    }
    nativeWindow_ = nativeWindow;
    surfaceValid_.store(true);
    glReady_.store(false);
    startThread();
    OH_LOG_INFO(LOG_APP, "StarRingGL onSurfaceCreated");
}

void StarRingRenderer::onSurfaceCreatedWithSize(void* nativeWindow, int32_t wPx, int32_t hPx) {
    if (wPx > 0 && hPx > 0) {
        surfW_.store(wPx);
        surfH_.store(hPx);
        OH_LOG_WARN(LOG_APP, "StarRingGL surface created with size %{public}dx%{public}d", wPx, hPx);
    } else {
        OH_LOG_WARN(LOG_APP, "StarRingGL surface created, size not ready");
    }
    onSurfaceCreated(nativeWindow);
}

void StarRingRenderer::onSurfaceChanged(int32_t wPx, int32_t hPx) {
    if (wPx <= 0 || hPx <= 0) {
        OH_LOG_WARN(LOG_APP, "StarRingGL onSurfaceChanged invalid %{public}dx%{public}d", wPx, hPx);
        return;
    }
    surfW_.store(wPx);
    surfH_.store(hPx);
    OH_LOG_WARN(LOG_APP, "StarRingGL onSurfaceChanged %{public}dx%{public}d", wPx, hPx);
}

void StarRingRenderer::onSurfaceDestroyed() {
    surfaceValid_.store(false);
    if (threadRunning_.load()) {
        threadRunning_.store(false);
        if (thread_.joinable()) {
            thread_.join();
        }
    }
    nativeWindow_ = nullptr;
    surfW_.store(0);
    surfH_.store(0);
    OH_LOG_WARN(LOG_APP, "StarRingGL onSurfaceDestroyed");
}

void StarRingRenderer::pause() {
    paused_.store(true);
    OH_LOG_INFO(LOG_APP, "StarRingGL pause");
}

void StarRingRenderer::resume() {
    paused_.store(false);
    OH_LOG_INFO(LOG_APP, "StarRingGL resume");
}

void StarRingRenderer::setDensity(float vpToPx) {
    if (vpToPx > 0.1f && vpToPx < 10.0f) {
        density_.store(vpToPx);
    }
}

void StarRingRenderer::setCenter(float cxRatio, float cyRatio, float baseWidthVp) {
    // 比例夹取 (0,1)，基准宽夹取 (0,4096]；baseWidthVp<=0 表示恢复独立全屏模式
    if (cxRatio > 0.0f && cxRatio < 1.0f) {
        cxRatio_.store(cxRatio);
    }
    if (cyRatio > 0.0f && cyRatio < 1.0f) {
        cyRatio_.store(cyRatio);
    }
    if (baseWidthVp >= 0.0f && baseWidthVp <= 4096.0f) {
        baseWVp_.store(baseWidthVp);
    }
    OH_LOG_INFO(LOG_APP, "StarRingGL setCenter cx=%{public}.3f cy=%{public}.3f baseW=%{public}.1f",
                cxRatio, cyRatio, baseWidthVp);
}

void StarRingRenderer::startThread() {
    // 重置喷射调度状态（surface 重建后从头开始）
    for (int s = 0; s < MAX_EJECT_SLOTS; s++) {
        slots_[s].idx = -1;
    }
    nextEjectAt_ = (double)ENTRANCE_DUR_S + 0.8;
    threadRunning_.store(true);
    paused_.store(false);
    thread_ = std::thread(&StarRingRenderer::renderLoop, this);
}

float StarRingRenderer::rand01() {
    std::uniform_real_distribution<float> dist(0.0f, 1.0f);
    return dist(rng_);
}

float StarRingRenderer::smoothstep(float k) const {
    float x = k < 0.0f ? 0.0f : (k > 1.0f ? 1.0f : k);
    return x * x * (3.0f - 2.0f * x);
}

float StarRingRenderer::radialBright(float rho) const {
    if (rho <= HOLE_RATIO) {
        return 0.0f;
    }
    float riseEnd = PEAK_RATIO - 0.03f;
    if (rho < riseEnd) {
        return smoothstep((rho - HOLE_RATIO) / (riseEnd - HOLE_RATIO));
    }
    float fallStart = PEAK_RATIO + 0.03f;
    if (rho <= fallStart) {
        return 1.0f;
    }
    float k = (rho - fallStart) / (RHO_MAX - fallStart);
    if (k > 1.0f) {
        k = 1.0f;
    }
    return 1.0f - 0.78f * smoothstep(k);
}

const float* StarRingRenderer::zoneWeightsOf(float rho) const {
    if (rho < 0.27f) return ZONE_W_INNER;
    if (rho < 0.38f) return ZONE_W_MID;
    if (rho < 0.44f) return ZONE_W_OUTER;
    return ZONE_W_FAR;
}

int StarRingRenderer::pickIndex(const float* weights, int n, float r) {
    float acc = 0.0f;
    for (int i = 0; i < n; i++) {
        acc += weights[i];
        if (r < acc) {
            return i;
        }
    }
    return n - 1;
}

void StarRingRenderer::hexToRgb(float* out, uint32_t hex) const {
    out[0] = (float)((hex >> 16) & 0xFF) / 255.0f;
    out[1] = (float)((hex >> 8) & 0xFF) / 255.0f;
    out[2] = (float)(hex & 0xFF) / 255.0f;
}

void StarRingRenderer::buildParticles() {
    ringR_ = (RHO_MIN + RHO_MAX) / 2.0f;
    tubeR_ = (RHO_MAX - RHO_MIN) / 2.0f;
    baseOmega_ = TWO_PI / ROTATION_PERIOD_S;
    float tilt = TILT_DEG * 3.14159265f / 180.0f;
    cT_ = cosf(tilt);
    sT_ = sinf(tilt);
    sq_ = SQUASH_Y;
    breathPhase_ = rand01() * TWO_PI;

    // 环粒子：16 floats/粒子（theta0, omega, rho, h, baseA, sizeCore, tier, colorIdx,
    //                                        jF1, jF2, jP1, jP2, twF, twP, burstD, seed）
    std::vector<float> ring(RING_COUNT * 16);
    for (int32_t i = 0; i < RING_COUNT; i++) {
        float* p = ring.data() + (size_t)i * 16;
        float r1 = rand01();
        float c;
        if (r1 < 0.42f) {
            c = -1.0f + rand01() * 0.65f;
        } else if (r1 < 0.75f) {
            c = -0.35f + rand01() * 0.70f;
        } else if (r1 < 0.93f) {
            c = 0.35f + rand01() * 0.40f;
        } else {
            c = 0.75f + rand01() * 0.25f;
        }
        float rho = ringR_ + tubeR_ * c;
        float hf = tubeR_ * sqrtf(fmaxf(0.0f, 1.0f - c * c));
        if (rand01() < 0.5f) {
            hf = -hf;
        }
        if (c > 0.75f) {
            hf *= 1.7f;
        }
        float omega = baseOmega_ * (1.0f + (DIFF_MAX - 1.0f) * (RHO_MAX - rho) / (RHO_MAX - RHO_MIN));
        float baseA = (0.55f + 0.45f * rand01()) * radialBright(rho);
        int tier = pickIndex(SPRITE_WEIGHT, TIER_COUNT, rand01());
        float sizeCore = SPRITE_CORE_PX[tier] * (0.9f + 0.2f * rand01());
        int colorIdx;
        if (rand01() < ACCENT_FRAC) {
            colorIdx = 4 + pickIndex(ACCENT_W, 3, rand01());
        } else {
            colorIdx = pickIndex(zoneWeightsOf(rho), 4, rand01());
        }
        p[0] = rand01() * TWO_PI;                  // theta0
        p[1] = omega;
        p[2] = rho;
        p[3] = hf;
        // 备份轨道（喷射方向计算）
        orbitBackup_[(size_t)i * 4 + 0] = p[0];
        orbitBackup_[(size_t)i * 4 + 1] = omega;
        orbitBackup_[(size_t)i * 4 + 2] = rho;
        orbitBackup_[(size_t)i * 4 + 3] = hf;
        p[4] = baseA;
        p[5] = sizeCore;
        p[6] = (float)tier;
        p[7] = (float)colorIdx;
        p[8] = 5.0f + 7.0f * rand01();             // jF1
        p[9] = 11.0f + 11.0f * rand01();           // jF2
        p[10] = rand01() * TWO_PI;                 // jP1
        p[11] = rand01() * TWO_PI;                 // jP2
        p[12] = 0.5f + 2.0f * rand01();            // twF
        p[13] = rand01() * TWO_PI;                 // twP
        p[14] = BURST_MIN_PX + rand01() * (BURST_MAX_PX - BURST_MIN_PX); // burstD
        p[15] = rand01();                          // seed
    }

    // 尘埃：8 floats（x0, y0, sizePx, speed, alpha, twF, twP, seed）
    std::vector<float> dust(DUST_COUNT * 8);
    for (int32_t i = 0; i < DUST_COUNT; i++) {
        float* p = dust.data() + (size_t)i * 8;
        p[0] = rand01();                                          // x0
        p[1] = 1.0f - powf(rand01(), 1.4f);                       // y0
        p[2] = 1.0f + rand01() * 2.0f;                            // sizePx
        p[3] = 2.0f + rand01() * 4.0f;                            // speed
        p[4] = 0.18f + 0.32f * rand01();                          // alpha
        p[5] = 0.3f + 0.9f * rand01();                            // twF
        p[6] = rand01() * TWO_PI;                                 // twP
        p[7] = rand01();
    }

    // 上传
    glBindBuffer(GL_ARRAY_BUFFER, ringVbo_);
    glBufferData(GL_ARRAY_BUFFER, ring.size() * sizeof(float), ring.data(), GL_STATIC_DRAW);
    glBindVertexArray(ringVao_);
    glBindBuffer(GL_ARRAY_BUFFER, ringVbo_);
    GLsizei stride = 16 * sizeof(float);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(0, 4, GL_FLOAT, GL_FALSE, stride, (void*)0);
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(1, 4, GL_FLOAT, GL_FALSE, stride, (void*)(4 * sizeof(float)));
    glEnableVertexAttribArray(2);
    glVertexAttribPointer(2, 4, GL_FLOAT, GL_FALSE, stride, (void*)(8 * sizeof(float)));
    glEnableVertexAttribArray(3);
    glVertexAttribPointer(3, 4, GL_FLOAT, GL_FALSE, stride, (void*)(12 * sizeof(float)));
    glBindBuffer(GL_ARRAY_BUFFER, 0);
    glBindVertexArray(0);

    glBindBuffer(GL_ARRAY_BUFFER, dustVbo_);
    glBufferData(GL_ARRAY_BUFFER, dust.size() * sizeof(float), dust.data(), GL_STATIC_DRAW);
    glBindVertexArray(dustVao_);
    glBindBuffer(GL_ARRAY_BUFFER, dustVbo_);
    GLsizei dstride = 8 * sizeof(float);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(0, 4, GL_FLOAT, GL_FALSE, dstride, (void*)0);
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(1, 4, GL_FLOAT, GL_FALSE, dstride, (void*)(4 * sizeof(float)));
    glBindBuffer(GL_ARRAY_BUFFER, 0);
    glBindVertexArray(0);
}

bool StarRingRenderer::initGL() {
    display_ = eglGetDisplay(EGL_DEFAULT_DISPLAY);
    if (display_ == EGL_NO_DISPLAY) {
        OH_LOG_ERROR(LOG_APP, "StarRingGL eglGetDisplay fail");
        return false;
    }
    if (!eglInitialize(display_, nullptr, nullptr)) {
        OH_LOG_ERROR(LOG_APP, "StarRingGL eglInitialize fail: %{public}x", eglGetError());
        return false;
    }
    EGLint cfgAttribs[] = {
        EGL_SURFACE_TYPE, EGL_WINDOW_BIT,
        EGL_RED_SIZE, 8, EGL_GREEN_SIZE, 8, EGL_BLUE_SIZE, 8, EGL_ALPHA_SIZE, 8,
        EGL_RENDERABLE_TYPE, EGL_OPENGL_ES3_BIT,
        EGL_NONE
    };
    EGLConfig config = nullptr;
    EGLint numConfigs = 0;
    if (!eglChooseConfig(display_, cfgAttribs, &config, 1, &numConfigs) || numConfigs < 1) {
        OH_LOG_ERROR(LOG_APP, "StarRingGL eglChooseConfig fail: %{public}x", eglGetError());
        return false;
    }
    EGLint ctxAttribs[] = {EGL_CONTEXT_CLIENT_VERSION, 3, EGL_NONE};
    context_ = eglCreateContext(display_, config, EGL_NO_CONTEXT, ctxAttribs);
    if (context_ == EGL_NO_CONTEXT) {
        OH_LOG_ERROR(LOG_APP, "StarRingGL eglCreateContext fail: %{public}x", eglGetError());
        return false;
    }
    surface_ = eglCreateWindowSurface(display_, config, (EGLNativeWindowType)nativeWindow_, nullptr);
    if (surface_ == EGL_NO_SURFACE) {
        OH_LOG_ERROR(LOG_APP, "StarRingGL eglCreateWindowSurface fail: %{public}x", eglGetError());
        return false;
    }
    if (!eglMakeCurrent(display_, surface_, surface_, context_)) {
        OH_LOG_ERROR(LOG_APP, "StarRingGL eglMakeCurrent fail: %{public}x", eglGetError());
        return false;
    }
    eglSwapInterval(display_, 1);

    // 点大小上限
    GLfloat ptRange[2] = {1.0f, 256.0f};
    glGetFloatv(GL_ALIASED_POINT_SIZE_RANGE, ptRange);
    ptMax_ = ptRange[1];
    OH_LOG_INFO(LOG_APP, "StarRingGL point size range %{public}.1f-%{public}.1f", ptRange[0], ptRange[1]);

    ringProgram_ = linkProgram(RING_VS, POINT_FS);
    dustProgram_ = linkProgram(DUST_VS, POINT_FS);
    vigProgram_ = linkProgram(QUAD_VS, VIG_FS);
    if (ringProgram_ == 0 || dustProgram_ == 0 || vigProgram_ == 0) {
        return false;
    }
    ringUniforms_[0] = glGetUniformLocation(ringProgram_, "uP0");
    ringUniforms_[1] = glGetUniformLocation(ringProgram_, "uP1");
    ringUniforms_[2] = glGetUniformLocation(ringProgram_, "uP2");
    ringUniforms_[3] = glGetUniformLocation(ringProgram_, "uP3");
    ringUniforms_[4] = glGetUniformLocation(ringProgram_, "uP4");
    ringUniforms_[5] = glGetUniformLocation(ringProgram_, "uEjectA");
    ringUniforms_[6] = glGetUniformLocation(ringProgram_, "uEjectB");
    ringUniforms_[7] = glGetUniformLocation(ringProgram_, "uSprite");
    ringUniforms_[8] = glGetUniformLocation(ringProgram_, "uColCore");
    GLint locInner = glGetUniformLocation(ringProgram_, "uColInner");
    GLint locMid = glGetUniformLocation(ringProgram_, "uColMid");
    GLint locEdge = glGetUniformLocation(ringProgram_, "uColEdge");
    dustUniforms_[0] = glGetUniformLocation(dustProgram_, "uP0");
    dustUniforms_[1] = glGetUniformLocation(dustProgram_, "uP1");
    dustUniforms_[2] = glGetUniformLocation(dustProgram_, "uP4");
    dustUniforms_[3] = glGetUniformLocation(dustProgram_, "uColC0");
    dustUniforms_[4] = glGetUniformLocation(dustProgram_, "uColC1");
    GLint locD2 = glGetUniformLocation(dustProgram_, "uColC2");
    GLint locD3 = glGetUniformLocation(dustProgram_, "uColC3");
    vigUniforms_[0] = glGetUniformLocation(vigProgram_, "uVig");

    // VBO/VAO
    glGenBuffers(1, &ringVbo_);
    glGenVertexArrays(1, &ringVao_);
    glGenBuffers(1, &dustVbo_);
    glGenVertexArrays(1, &dustVao_);
    glGenBuffers(1, &quadVbo_);
    glGenVertexArrays(1, &quadVao_);

    buildParticles();

    // 静态 uniform（环粒子）
    float sprites[TIER_COUNT][3];
    for (int t = 0; t < TIER_COUNT; t++) {
        sprites[t][0] = SPRITE_STOPS[t][0];
        sprites[t][1] = SPRITE_STOPS[t][1];
        sprites[t][2] = SPRITE_STOPS[t][2];
    }
    float colCore[COLOR_COUNT][3];
    float colInner[COLOR_COUNT][3];
    float colMid[COLOR_COUNT][3];
    float colEdge[COLOR_COUNT][3];
    for (int ci = 0; ci < COLOR_COUNT; ci++) {
        hexToRgb(colCore[ci], COLOR_HEX[ci][0]);
        hexToRgb(colInner[ci], COLOR_HEX[ci][1]);
        hexToRgb(colMid[ci], COLOR_HEX[ci][2]);
        hexToRgb(colEdge[ci], COLOR_HEX[ci][3]);
    }
    glUseProgram(ringProgram_);
    glUniform3fv(ringUniforms_[7], TIER_COUNT, &sprites[0][0]);
    glUniform3fv(ringUniforms_[8], COLOR_COUNT, &colCore[0][0]);
    glUniform3fv(locInner, COLOR_COUNT, &colInner[0][0]);
    glUniform3fv(locMid, COLOR_COUNT, &colMid[0][0]);
    glUniform3fv(locEdge, COLOR_COUNT, &colEdge[0][0]);

    // 尘埃颜色 = COLOR_HEX[1]
    glUseProgram(dustProgram_);
    float d0[3], d1[3], d2[3], d3[3];
    hexToRgb(d0, COLOR_HEX[1][0]);
    hexToRgb(d1, COLOR_HEX[1][1]);
    hexToRgb(d2, COLOR_HEX[1][2]);
    hexToRgb(d3, COLOR_HEX[1][3]);
    glUniform3fv(dustUniforms_[3], 1, d0);
    glUniform3fv(dustUniforms_[4], 1, d1);
    glUniform3fv(locD2, 1, d2);
    glUniform3fv(locD3, 1, d3);

    // 全屏 quad
    float quad[] = {-1.0f, -1.0f, 1.0f, -1.0f, -1.0f, 1.0f, 1.0f, 1.0f};
    glBindVertexArray(quadVao_);
    glBindBuffer(GL_ARRAY_BUFFER, quadVbo_);
    glBufferData(GL_ARRAY_BUFFER, sizeof(quad), quad, GL_STATIC_DRAW);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, 2 * sizeof(float), (void*)0);
    glBindBuffer(GL_ARRAY_BUFFER, 0);
    glBindVertexArray(0);

    glDisable(GL_DEPTH_TEST);
    glClearColor(BG_R, BG_G, BG_B, 1.0f);
    return true;
}

void StarRingRenderer::destroyGL() {
    if (display_ == EGL_NO_DISPLAY) {
        return;
    }
    eglMakeCurrent(display_, EGL_NO_SURFACE, EGL_NO_SURFACE, EGL_NO_CONTEXT);
    if (ringVao_) { glDeleteVertexArrays(1, &ringVao_); ringVao_ = 0; }
    if (ringVbo_) { glDeleteBuffers(1, &ringVbo_); ringVbo_ = 0; }
    if (dustVao_) { glDeleteVertexArrays(1, &dustVao_); dustVao_ = 0; }
    if (dustVbo_) { glDeleteBuffers(1, &dustVbo_); dustVbo_ = 0; }
    if (quadVao_) { glDeleteVertexArrays(1, &quadVao_); quadVao_ = 0; }
    if (quadVbo_) { glDeleteBuffers(1, &quadVbo_); quadVbo_ = 0; }
    if (ringProgram_) { glDeleteProgram(ringProgram_); ringProgram_ = 0; }
    if (dustProgram_) { glDeleteProgram(dustProgram_); dustProgram_ = 0; }
    if (vigProgram_) { glDeleteProgram(vigProgram_); vigProgram_ = 0; }
    if (surface_ != EGL_NO_SURFACE) { eglDestroySurface(display_, surface_); surface_ = EGL_NO_SURFACE; }
    if (context_ != EGL_NO_CONTEXT) { eglDestroyContext(display_, context_); context_ = EGL_NO_CONTEXT; }
    // 不 eglTerminate：display 为进程内共享（视频导出离屏渲染也在用 default display）
    display_ = EGL_NO_DISPLAY;
}

bool StarRingRenderer::particleBusy(int32_t idx) const {
    for (int s = 0; s < MAX_EJECT_SLOTS; s++) {
        if (slots_[s].idx == idx) {
            return true;
        }
    }
    return false;
}

void StarRingRenderer::spawnEjects(double t) {
    int32_t n = EJECT_COUNT_MIN + (int32_t)(rand01() * (float)(EJECT_COUNT_MAX - EJECT_COUNT_MIN + 1));
    int32_t tries = 0;
    int32_t spawned = 0;
    const int32_t maxTries = n * 8;
    while (spawned < n && tries < maxTries) {
        tries++;
        int32_t i = (int32_t)(rand01() * (float)RING_COUNT);
        if (i >= RING_COUNT || particleBusy(i)) {
            continue;
        }
        // 找空闲槽
        int slot = -1;
        for (int s = 0; s < MAX_EJECT_SLOTS; s++) {
            if (slots_[s].idx < 0) {
                slot = s;
                break;
            }
        }
        if (slot < 0) {
            break;
        }
        // 方向：按该粒子当前 3D 投影位置径向向外（与原版一致）
        float theta0 = orbitBackup_[(size_t)i * 4 + 0];
        float omega = orbitBackup_[(size_t)i * 4 + 1];
        float rho = orbitBackup_[(size_t)i * 4 + 2];
        float hv = orbitBackup_[(size_t)i * 4 + 3];
        float th = theta0 + omega * (float)t;
        float rx = rho * wd_;
        float hvv = hv * wd_;
        float dx = rx * cosf(th);
        float dy = (rx * sinf(th) * cT_ + hvv * sT_) * sq_;
        float len = sqrtf(dx * dx + dy * dy);
        if (len < 1e-6f) {
            dx = 0.0f;
            dy = -1.0f;
        } else {
            dx /= len;
            dy /= len;
        }
        slots_[slot].idx = i;
        slots_[slot].t0 = (float)t;
        slots_[slot].dur = EJECT_DUR_MIN_S + rand01() * (EJECT_DUR_MAX_S - EJECT_DUR_MIN_S);
        slots_[slot].dist = EJECT_DIST_PX * scale1080_ * (0.7f + 0.6f * rand01());
        slots_[slot].dirX = dx;
        slots_[slot].dirY = dy;
        spawned++;
    }
}

void StarRingRenderer::renderLoop() {
    if (!initGL()) {
        OH_LOG_ERROR(LOG_APP, "StarRingGL initGL fail, thread exit");
        destroyGL();
        glReady_.store(false);
        threadRunning_.store(false);
        return;
    }
    glReady_.store(true);
    OH_LOG_WARN(LOG_APP, "StarRingGL render thread started");

    double t = 0.0;
    auto lastTime = std::chrono::steady_clock::now();
    int32_t lastW = 0;
    int32_t lastH = 0;

    while (threadRunning_.load()) {
        auto frameStart = std::chrono::steady_clock::now();

        if (paused_.load() || !surfaceValid_.load()) {
            std::this_thread::sleep_for(std::chrono::milliseconds(100));
            lastTime = frameStart;
            continue;
        }

        int32_t wPx = surfW_.load();
        int32_t hPx = surfH_.load();
        if (wPx <= 0 || hPx <= 0) {
            std::this_thread::sleep_for(std::chrono::milliseconds(50));
            lastTime = frameStart;
            continue;
        }

        auto now = std::chrono::steady_clock::now();
        double dtMs = std::chrono::duration<double, std::milli>(now - lastTime).count();
        lastTime = now;
        if (dtMs < 0.0) {
            dtMs = 0.0;
        }
        if (dtMs > 50.0) {
            dtMs = 50.0;
        }
        t += dtMs / 1000.0;

        float density = density_.load();
        float baseW = baseWVp_.load();
        wVp_ = (float)wPx / density;
        hVp_ = (float)hPx / density;
        if (baseW > 0.0f) {
            // 应用内嵌模式：环基准宽由 ArkTS 指定（与全屏 demo 同尺寸的精灵比例），
            // 环心比例可调；vignette 由绘制段跳过
            scale1080_ = baseW / 1080.0f;
            wd_ = baseW;
        } else {
            scale1080_ = wVp_ / 1080.0f;
            wd_ = fminf(wVp_, hVp_ * 1080.0f / 1920.0f);
        }
        cxVp_ = wVp_ * cxRatio_.load();
        cyVp_ = hVp_ * cyRatio_.load();
        jitAmpVp_ = JITTER_AMP_PX * scale1080_;
        depthNorm_ = RHO_MAX * wd_;

        if (wPx != lastW || hPx != lastH) {
            glViewport(0, 0, wPx, hPx);
            lastW = wPx;
            lastH = hPx;
        }

        // 入场/呼吸（CPU 每帧，仅标量）
        float pd = (float)(t / (double)ENTRANCE_DUR_S);
        if (pd > 1.0f) {
            pd = 1.0f;
        }
        float pe = 1.0f - (1.0f - pd) * (1.0f - pd) * (1.0f - pd);
        float gAlpha = pe;
        float breath = 1.0f + BREATH_AMP * sinf((float)t * TWO_PI / BREATH_PERIOD_S + breathPhase_);
        float gs = (0.6f + 0.4f * pe) * breath;

        // 喷射调度
        bool ejectOn = false;
        int activeSlots = 0;
        if (pd >= 1.0f) {
            if (t >= nextEjectAt_) {
                spawnEjects(t);
                nextEjectAt_ = t + (double)(EJECT_INTERVAL_S * (0.75 + 0.5 * (double)rand01()));
            }
            for (int s = 0; s < MAX_EJECT_SLOTS; s++) {
                EjectSlot& sl = slots_[s];
                if (sl.idx < 0) {
                    continue;
                }
                // 槽过期回收（含 refill 淡入期）
                if ((float)t - sl.t0 > sl.dur + REFILL_FADE_S) {
                    sl.idx = -1;
                    continue;
                }
                activeSlots++;
            }
            ejectOn = activeSlots > 0;
            if (ejectOn) {
                for (int s = 0; s < MAX_EJECT_SLOTS; s++) {
                    const EjectSlot& sl = slots_[s];
                    ejectUploadA_[s][0] = (float)sl.idx;
                    ejectUploadA_[s][1] = sl.t0;
                    ejectUploadA_[s][2] = sl.dur;
                    ejectUploadA_[s][3] = sl.dist;
                    ejectUploadB_[s][0] = sl.dirX;
                    ejectUploadB_[s][1] = sl.dirY;
                    ejectUploadB_[s][2] = 0.0f;
                    ejectUploadB_[s][3] = 0.0f;
                }
            }
        }

        // ===== 绘制 =====
        glClear(GL_COLOR_BUFFER_BIT);

        // 尘埃（加性）
        glEnable(GL_BLEND);
        glBlendFunc(GL_ONE, GL_ONE);
        glUseProgram(dustProgram_);
        glUniform4f(dustUniforms_[0], (float)t, pe, gs, gAlpha);
        glUniform4f(dustUniforms_[1], wVp_, hVp_, density, scale1080_);
        glUniform4f(dustUniforms_[2], REFILL_FADE_S, ptMax_, TWINKLE_AMP, 0.0f);
        glBindVertexArray(dustVao_);
        glDrawArrays(GL_POINTS, 0, DUST_COUNT);

        // 环粒子（加性）
        glUseProgram(ringProgram_);
        glUniform4f(ringUniforms_[0], (float)t, pe, gs, gAlpha);
        glUniform4f(ringUniforms_[1], wVp_, hVp_, density, scale1080_);
        glUniform4f(ringUniforms_[2], wd_, cxVp_, cyVp_, jitAmpVp_);
        glUniform4f(ringUniforms_[3], cT_, sT_, sq_, depthNorm_);
        glUniform4f(ringUniforms_[4], REFILL_FADE_S, ptMax_, TWINKLE_AMP, ejectOn ? 1.0f : 0.0f);
        if (ejectOn) {
            glUniform4fv(ringUniforms_[5], MAX_EJECT_SLOTS, &ejectUploadA_[0][0]);
            glUniform4fv(ringUniforms_[6], MAX_EJECT_SLOTS, &ejectUploadB_[0][0]);
        } else {
            glUniform4f(ringUniforms_[5], -1.0f, 0.0f, 0.0f, 0.0f);
        }
        glBindVertexArray(ringVao_);
        glDrawArrays(GL_POINTS, 0, RING_COUNT);

        // vignette（普通 alpha 混合）：仅独立全屏模式绘制；
        // 应用内嵌方盒内四角暗化会露出方盒边缘，跳过（盒底色与压暗层同色无缝）
        if (baseW <= 0.0f) {
            glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
            glUseProgram(vigProgram_);
            glUniform2f(vigUniforms_[0], VIGNETTE_STRENGTH, gAlpha);
            glBindVertexArray(quadVao_);
            glDrawArrays(GL_TRIANGLE_STRIP, 0, 4);
        }
        glBindVertexArray(0);

        eglSwapBuffers(display_, surface_);
        if (!firstFrameLogged_) {
            firstFrameLogged_ = true;
            OH_LOG_WARN(LOG_APP, "StarRingGL first frame drawn %{public}dx%{public}d", wPx, hPx);
            // 角度分布诊断：12 扇区统计 theta0（CPU 侧上传数据）
            int bins[12] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
            for (int32_t i = 0; i < RING_COUNT; i++) {
                float deg = fmodf(orbitBackup_[(size_t)i * 4] * (180.0f / 3.14159265f), 360.0f);
                if (deg < 0.0f) {
                    deg += 360.0f;
                }
                bins[(int)(deg / 30.0f) % 12]++;
            }
            OH_LOG_WARN(LOG_APP,
                "StarRingGL theta bins %{public}d %{public}d %{public}d %{public}d %{public}d %{public}d"
                " %{public}d %{public}d %{public}d %{public}d %{public}d %{public}d",
                bins[0], bins[1], bins[2], bins[3], bins[4], bins[5],
                bins[6], bins[7], bins[8], bins[9], bins[10], bins[11]);
            OH_LOG_WARN(LOG_APP,
                "StarRingGL state t=%{public}.2f pe=%{public}.2f density=%{public}.2f"
                " wVp=%{public}.0f hVp=%{public}.0f wd=%{public}.0f cx=%{public}.0f cy=%{public}.0f",
                (float)t, pe, density, wVp_, hVp_, wd_, cxVp_, cyVp_);
        }

        // 60fps 节流：sleep 让出 CPU（vsync 之上再限帧）
        double frameCostMs = std::chrono::duration<double, std::milli>(
            std::chrono::steady_clock::now() - frameStart).count();
        double sleepMs = FRAME_INTERVAL_MS - frameCostMs;
        if (sleepMs > 1.0) {
            std::this_thread::sleep_for(std::chrono::microseconds((int64_t)(sleepMs * 1000.0)));
        }
    }

    destroyGL();
    glReady_.store(false);
    OH_LOG_INFO(LOG_APP, "StarRingGL render thread exit");
}
