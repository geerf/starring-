/**
 * StarringFX — GPU 星环粒子渲染器 NAPI 接口
 * 库文件：libstarringfx.so（XComponent libraryname: 'starringfx'）
 */

/**
 * 注册 XComponent surface 生命周期回调。
 * 在 XComponent.onLoad(ctx) 中调用：registerStarRingContext(ctx)。
 * 注册后 surface 创建/尺寸变化/销毁会自动驱动渲染器（无需手动调用 surface 相关接口）。
 */
export const registerStarRingContext: (ctx: object) => boolean;
/**
 * 设置屏幕密度（vp → px），影响粒子尺寸/抖动幅度等观感。
 * 传 display.getDefaultDisplaySync().densityPixels。
 */
export const setStarRingDensity: (densityPixels: number) => void;
/**
 * 应用内嵌模式：设置环心在 surface 内的宽/高比例 + 环基准宽（vp）。
 * 环半径 = boxSide / 2 - 90（vp，尘埃边距）。
 * baseWidthVp > 0：内嵌模式（推荐 baseWidthVp = min(winW, winH * 1080 / 1920)，
 *   对应 XComponent 盒宽 = min(2 * (0.47 * baseWidthVp + 90), max(winW, winH))）；
 * baseWidthVp = 0：恢复独立全屏模式（默认环心比例 0.52 / 0.44，含 vignette）。
 */
export const setStarRingCenter: (cxRatio: number, cyRatio: number, baseWidthVp: number) => void;
/**
 * 主动推送 surface 视口尺寸（px）。部分 PC 端 OnSurfaceChanged 不回调，
 * 窗口拉伸后由 ArkTS 侧计算组件尺寸（vp × densityPixels）推送；手机端可不调（回调自动同步，调了也幂等）。
 */
export const notifyStarRingSurfaceSize: (wPx: number, hPx: number) => void;
/** 暂停渲染（渲染线程休眠，surface 保留） */
export const starRingPause: () => void;
/** 恢复渲染 */
export const starRingResume: () => void;
