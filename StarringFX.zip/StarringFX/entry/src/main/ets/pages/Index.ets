import nativeCap from 'libstarringfx.so';
import display from '@ohos.display';

// StarringFX 演示页：全屏 GPU 星环 + 两个控制按钮（暂停/恢复、全屏/内嵌模式切换）
@Entry
@Component
struct Index {
  @State paused: boolean = false;
  @State embedded: boolean = false;
  private densityPx: number = 1;
  private windowWidthVp: number = 0;
  private windowHeightVp: number = 0;

  // 切换独立全屏模式（默认观感：环心 0.52/0.44 + vignette）与应用内嵌模式（环心居中 + 指定基准宽）
  private toggleMode(): void {
    this.embedded = !this.embedded;
    try {
      if (this.embedded && this.windowWidthVp > 0 && this.windowHeightVp > 0) {
        const baseW: number = Math.min(this.windowWidthVp, this.windowHeightVp * 1080 / 1920);
        nativeCap.setStarRingCenter(0.5, 0.5, baseW);
      } else {
        // baseWidthVp=0 恢复独立全屏模式（默认环心比例）
        nativeCap.setStarRingCenter(0.52, 0.44, 0);
      }
    } catch (err) {
      console.error(`[StarringFX] toggleMode failed: ${err}`);
    }
  }

  private togglePause(): void {
    this.paused = !this.paused;
    try {
      if (this.paused) {
        nativeCap.starRingPause();
      } else {
        nativeCap.starRingResume();
      }
    } catch (err) {
      console.error(`[StarringFX] togglePause failed: ${err}`);
    }
  }

  build() {
    Stack({ alignContent: Alignment.Bottom }) {
      XComponent({
        id: 'starring_demo',
        type: XComponentType.SURFACE,
        libraryname: 'starringfx'
      })
        .onLoad((ctx?: object) => {
          if (ctx) {
            try {
              nativeCap.registerStarRingContext(ctx);
            } catch (err) {
              console.error(`[StarringFX] registerStarRingContext failed: ${err}`);
            }
          }
          try {
            this.densityPx = display.getDefaultDisplaySync().densityPixels;
            nativeCap.setStarRingDensity(this.densityPx);
          } catch (err) {
            console.error(`[StarringFX] setStarRingDensity failed: ${err}`);
          }
        })
        .width('100%')
        .height('100%')

      Row({ space: 12 }) {
        Button(this.paused ? 'Resume' : 'Pause')
          .fontSize(14)
          .width(110)
          .onClick((): void => {
            this.togglePause();
          })
        Button(this.embedded ? 'Fullscreen' : 'Embedded')
          .fontSize(14)
          .width(110)
          .onClick((): void => {
            this.toggleMode();
          })
      }
      .margin({ bottom: 48 })
    }
    .width('100%')
    .height('100%')
    .backgroundColor('#FF050507')
    .onAreaChange((_: Area, area: Area) => {
      const w: number = Number(`${area.width}`.replace('vp', '').replace('px', ''));
      const h: number = Number(`${area.height}`.replace('vp', '').replace('px', ''));
      const sizeChanged: boolean = w !== this.windowWidthVp || h !== this.windowHeightVp;
      this.windowWidthVp = w;
      this.windowHeightVp = h;
      // 窗口拉伸时：内嵌模式跟随重算基准宽；PC 端 OnSurfaceChanged 不回调，主动推送视口尺寸
      if (sizeChanged && this.embedded) {
        const baseW: number = Math.min(this.windowWidthVp, this.windowHeightVp * 1080 / 1920);
        try {
          nativeCap.setStarRingCenter(0.5, 0.5, baseW);
          nativeCap.notifyStarRingSurfaceSize(
            this.windowWidthVp * this.densityPx, this.windowHeightVp * this.densityPx);
        } catch (err) {
          console.error(`[StarringFX] onAreaChange refresh failed: ${err}`);
        }
      }
    })
  }
}
